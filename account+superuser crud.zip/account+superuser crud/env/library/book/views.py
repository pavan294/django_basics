from django.shortcuts import render
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
# Create your views here.
def student(request):
    return render(request,'studentlogin.html')
def studentdashboard(request):
    if request.method == "POST":
        username=request.POST['password']
        user = authenticate(username=request.POST['username'], password=request.POST['password'])
        if user:
           return render(request,'studentdashboard.html')
        else:
           return render(request,'studenttest.html')
    else:
        pass
def adduserform(request):
    return render(request,'adduserform.html')
def updateuserform(request):
    return render(request,'updateuserform.html')
def deleteuserform(request):
    return render(request,'deleteuserform.html')
def adduser(request):
    if request.method=="POST":
        username=request.POST['user']
        password=request.POST['pass']
        user = User.objects.create_user(username)
        user.set_password(password)
        user.save()
        result="user added"
        return render(request,'result.html',{'result':result})
    else:
        result="user not added"
        return render(request,'result.html',{'result':result})
def updateuser(request):
        username=request.POST['user']
        password=request.POST['oldpass']
        user = authenticate(username=username, password=password)
        if user:
            k=User.objects.get(username=username)
            password1=request.POST['newpass']
            k.set_password(password1)
       	    k.save()
            result="user updated"
        else:
            result="user does not exist"
        return render(request,'result.html',{'result':result})
def deleteuser(request):
    user = authenticate(username=request.POST['user'], password=request.POST['pass'])
    if user:
        k=User.objects.get(username=request.POST['user'])
        k.delete()
        result="user deleted"
    else:
            result="user does not exist"
    return render(request, 'result.html', {'result':result}) 


