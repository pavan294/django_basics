"""library URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from . import views
from django.urls import path
urlpatterns = [
    path('student',views.student,name="student"),
    path('studentdashboard',views.studentdashboard,name="studentdashboard"),
    path('adduserform',views.adduserform,name="adduserform"),
    path('updateuserform',views.updateuserform,name="updateuserform"),
    path('deleteuserform',views.deleteuserform,name="deleteuserform"),
    path('adduser',views.adduser,name="adduser"),
    path('updateuser',views.updateuser,name="updateuser"),
    path('deleteuser',views.deleteuser,name="deleteuser"),
    path('studentList',views.studentList,name="studentList"),
    path('studentDetailForm',views.studentDetailForm,name="studentDetailForm"),
    path('studentDetail',views.studentDetail,name="studentDetail"),
    path('genreaddform',views.genreaddform,name="genreaddform"),
    path('genreadd',views.genreadd,name="genreadd"),
    path('genredeleteform',views.genredeleteform,name="genredeleteform"),
    path('genredelete',views.genredelete,name="genredelete"),
    path('genrelist',views.genrelist,name="genrelist"),
    path('lanaddform',views.lanaddform,name="lanaddform"),
    path('lanadd',views.lanadd,name="lanadd"),
    path('landeleteform',views.landeleteform,name="landeleteform"),
    path('landelete',views.landelete,name="landelete"),
    path('lanlist',views.lanlist,name="lanlist"),
    path('addbookform',views.addbookform,name="addbookform"),
    path('updatebookform',views.updatebookform,name="updatebookform"),
    path('deletebookform',views.deletebookform,name="deletebookform"),
    path('addbook',views.addbook,name="addbook"),
    path('updatebook',views.updatebook,name="updatebook"),
    path('deletebook',views.deletebook,name="deletebook"),
    path('booklist',views.booklist,name="booklist"),
    path('bookdetailform',views.bookdetailform,name="bookdetailform"),
    path('bookdetail',views.bookdetail,name="bookdetail"),
    path('bookdetailform1',views.bookdetailform1,name="bookdetailform1"),
    path('bookdetail1',views.bookdetail1,name="bookdetail1"),
    path('bookdetailform2',views.bookdetailform2,name="bookdetailform2"),
    path('bookdetail2',views.bookdetail2,name="bookdetail2"),
    path('addborrowerform',views.addborrowerform,name="addborrowerform"),
    path('addborrower',views.addborrower,name="addborrower"),
    path('updateborrowerform',views.updateborrowerform,name="updateborrowerform"),
    path('updateborrower',views.updateborrower,name="updateborrower"),
    path('borrowerlist',views.borrowerlist,name="borrowerlist"),
    path('borrowerdetail1form',views.borrowerdetail1form,name="borrowerdetail1form"),
    path('borrowerdetail1',views.borrowerdetail1,name="borrowerdetail1"),
    path('borrowerdetail2form',views.borrowerdetail2form,name="borrowerdetail2form"),
    path('borrowerdetail2',views.borrowerdetail2,name="borrowerdetail2"),
]
