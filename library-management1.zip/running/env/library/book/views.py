from django.shortcuts import render
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from book.forms import StudentForm,BookForm,BookUpdateForm
from book.models import Student,Genre,Language,Book,Borrower
import datetime
# Create your views here.
def student(request):
    return render(request,'studentlogin.html')
def studentdashboard(request):
    if request.method == "POST" :
        if Student.objects.filter(roll_no=request.POST['username'],password=request.POST['password']).exists():
           return render(request,'studentdashboard.html',{'p':request.POST['username']})
        else:
           result="enter valid credentials"
           return render(request,'resultv.html',{'result':result})
def basepage(request):
    return render(request,'basepage.html')
def studentdashboard1(request,parameter):
     return render(request,'studentdashboard.html',{'p':parameter})
        
def adduserform(request):
    form=StudentForm()
    return render(request,'adduserform.html',{'form':form})
def updateuserform(request):
    form=StudentForm()
    return render(request,'updateuserform.html',{'form':form})
def deleteuserform(request):
    return render(request,'deleteuserform.html')
def adduser(request):
    if request.method == "POST":  
       k=StudentForm(data=request.POST)
       if Student.objects.filter(roll_no=k['roll_no'].value()).exists():
          result="student already exists"
       else:
          p=StudentForm(request.POST)
          if p.is_valid():
             p.total_books_due=0
             p.save()
             result="student added"
          else:
             result="form invalid"
       return render(request,'result.html',{'result':result})
def updateuser(request):
       if request.method == "POST":  
            pa=StudentForm(data=request.POST)
            if Student.objects.filter(roll_no=pa['roll_no'].value()).exists():
                obj =Student.objects.get(roll_no=pa['roll_no'].value())
                form =StudentForm(request.POST,instance = obj)
                if form.is_valid():
                    form.save()
                    result="student updated"
                else:
                    result="form invalid"
            else:
                result="student does not exist to update"
            return render(request,'result.html',{'result':result})
def deleteuser(request):
    if request.method == "POST" :
        k=request.POST['rollno']
        if Student.objects.filter(roll_no=k).exists():
           p=Student.objects.get(roll_no=k)
           if p.total_books_due>=1:
              result="student cannot be deleted and has to clear total books due"
           else:
              p.delete()
              result="student deleted"
        else:
           result="student does not exist to delete"
        return render(request, 'result.html', {'result':result})
def studentList(request):
    result=Student.objects.all()
    return render(request, 'studentlist.html', {'result':result})
def studentDetailForm(request):
    return render(request,'studentdetailform.html')
def studentDetail(request):
    if request.method == "POST" :
        if Student.objects.filter(roll_no=request.POST['rollno']).exists():
            data=Student.objects.get(roll_no=request.POST['rollno'])
            return render(request, 'studentDetail.html', {'i':data})
        else:
            data="student not found"
            return render(request, 'result.html', {'result':data})
def genreaddform(request):
    return render(request,'genreaddform.html')
def genreadd(request):
    if request.method == "POST" :
        k=request.POST['name']
        if Genre.objects.filter(name=k).exists():
           result="student already exists"
        else:
            p=Genre(name=k)
            p.save()
            result="genre added"
    return render(request, 'result.html', {'result':result})
def genredeleteform(request):
    return render(request,'genredeleteform.html')
def genredelete(request):
    if request.method == "POST" :
        k=request.POST['name']
        if Genre.objects.filter(name=k).exists():
           p=Genre.objects.get(name=k)
           p.delete()
           result="genre deleted"
        else:
            result="genre does not exist to delete"
        return render(request, 'result.html', {'result':result})
def genrelist(request):
    result=Genre.objects.all()
    return render(request, 'genrelist.html', {'result':result})
def lanaddform(request):
    return render(request,'lanaddform.html')
def lanadd(request):
    if request.method == "POST" :
        k=request.POST['name']
        if Language.objects.filter(name=k).exists():
           result="Language already exists"
        else:
            p=Language(name=k)
            p.save()
            result="Language added"
        return render(request, 'result.html', {'result':result})
def landeleteform(request):
    return render(request,'landeleteform.html')
def landelete(request):
    if request.method == "POST" :
        k=request.POST['name']
        if Language.objects.filter(name=k).exists():
           p=Language.objects.get(name=k)
           p.delete()
           result="Language deleted"
        else:
           result="Language does not exist to delete"
        return render(request, 'result.html', {'result':result})
def lanlist(request):
    result=Language.objects.all()
    return render(request, 'lanlist.html', {'result':result})
def addbookform(request):
    form=BookForm()
    return render(request,'addbookform.html',{'form':form})
def updatebookform(request):
    form=BookUpdateForm()
    return render(request,'updatebookform.html',{'form':form})
def deletebookform(request):
    return render(request,'deletebookform.html')
def addbook(request):
    if request.method == "POST":  
       k=BookForm(data=request.POST)
       z=BookForm(request.POST)
       if z.is_valid():
          if z.cleaned_data['total_copies']>= z.cleaned_data['available_copies']:
              z.save()
              result="book added"
          else:
             result="book cannot be added "
       else:
          result="invalid form "  
    
       return render(request,'result.html',{'result':result})
def updatebook(request):
       if request.method == "POST":  
            k=BookForm(data=request.POST)
            t=request.POST['title']
            if  Book.objects.filter(title=t).exists():
                 obj =Book.objects.filter(title=k['title'].value())
                 for i in obj:
                     i.author=k['author'].value()
                     i.summary=k['summary'].value()
                     i.version=k['version'].value()
                     i.save()
                 result="Book updated"
            else:
                result="book cannot be updated "
            return render(request,'result.html',{'result':result})
def deletebook(request):
    if request.method == "POST" :
        k=request.POST['title']
        if Book.objects.filter(title=k).exists():
           p=Book.objects.filter(title=k)
           for i in p:
               p.delete()
           result="book deleted"
        else:
           result="book does not exist to delete"
        return render(request, 'result.html', {'result':result})
def booklist(request):
    result=Book.objects.all()
    return render(request, 'booklist.html', {'result':result})
def bookdetailform(request):
    return render(request,'bookdetailform.html')
def bookdetailform1(request):
    return render(request,'bookdetailform1.html')
def bookdetailform2(request):
    return render(request,'bookdetailform2.html')
def bookdetail(request):
    if request.method == "POST" :
        if Book.objects.filter(title=request.POST['title']).exists():
           data=Book.objects.filter(title=request.POST['title'])
           return render(request, 'bookdetail.html', {'result':data})
        else:
           data="Books not found"
           return render(request, 'result.html', {'result':data})
def bookdetail1(request):
    if request.method == "POST" :
        if Book.objects.filter(genre__name=request.POST['genre']).exists():
           data=Book.objects.filter(genre__name=request.POST['genre'])
           return render(request, 'bookdetail.html', {'result':data})
        else:
           data="Books not found"
           return render(request, 'result.html', {'result':data})
def bookdetail2(request):
    if request.method == "POST" :
        if Book.objects.filter(language__name=request.POST['language']).exists():
           data=Book.objects.filter(language__name=request.POST['language'])
           return render(request, 'bookdetail.html', {'result':data})
        else:
           data="Books not found"
           return render(request, 'result.html', {'result':data})
def addborrowerform(request):
    return render(request,'addborrowerform.html')
def addborrower(request):
    if request.method == "POST" :
        k=request.POST['title']
        p=request.POST['roll_no']
        if Book.objects.filter(title=k).exists() and Student.objects.filter(roll_no=p).exists():
            obj = Book.objects.get(title=k)
            s=Student.objects.get(roll_no=p)
            if s.total_books_due < 10:
                message = "book has been issued, You can collect book from library"
                a = Borrower()
                a.student = s
                a.book = obj
                a.issue_date = datetime.datetime.now()
                if obj.available_copies -1>=1:
                    obj.available_copies = obj.available_copies - 1
                    obj.save()
                    s.total_books_due=s.total_books_due+1
                    s.save()
                    a.save()
                else:
                    message = "No available books to issue"
            else:
                message = "you have exceeded limit."
        else:
            message="invalid student or book"
        return render(request, 'result.html',{'result':message})
    
def updateborrowerform(request):
    return render(request,'updateborrowerform.html')
def updateborrower(request):
    if request.method == "POST" :
        k=request.POST['title']
        p=request.POST['roll_no']
        if Book.objects.filter(title=k).exists() and Student.objects.filter(roll_no=p).exists() and Borrower.objects.filter(student__roll_no=p,book__title=k).exists():
            obj = Book.objects.get(title=k)
            s=Student.objects.get(roll_no=p)
            s.total_books_due=s.total_books_due-1
            obj.available_copies=obj.available_copies+1
            s.save()
            obj.save()
            Borrower.objects.filter(student=s,book=obj).first().delete()
            message="book successfully return"
        else:
            message="borrower does not exist"
        return render(request, 'result.html',{'result':message})
def borrowerlist(request):
    k=Borrower.objects.all()
    return render(request, 'borrowerlist.html',{'result':k})
def borrowerdetail1form(request):
    return render(request,'borrowerdetail1form.html')
def borrowerdetail1(request):
    if request.method == "POST" :
        p=request.POST['roll_no']
        if Student.objects.filter(roll_no=p).exists():
            if Borrower.objects.filter(student__roll_no=p).exists():
                a=Borrower.objects.filter(student__roll_no=p)
                result=a
                return render(request, 'borrowerlist.html',{'result':result})
            else:
                result="borrower not found"
                return render(request, 'result.html',{'result':result})
        else:
            result="borrower not found as student invalid"
            return render(request, 'result.html',{'result':result})
def borrowerdetail2form(request):
    return render(request,'borrowerdetail2form.html')
def borrowerdetail2(request):
    if request.method == "POST" :
        p=request.POST['title']
        if Book.objects.filter(title=p).exists():
            if Borrower.objects.filter(book__title=p).exists():
                a=Borrower.objects.filter(book__title=p)
                result=a
                return render(request, 'borrowerlist.html',{'result':result})
            else:
                result="borrower not found"
                return render(request, 'result.html',{'result':result})
        else:
            result="borrower not found as book invalid"
            return render(request, 'result.html',{'result':result})
        
def borrowerdetailbyroll(request,parameter):
    p=parameter
    if Student.objects.filter(roll_no=p).exists():
        if Borrower.objects.filter(student__roll_no=p).exists():
            a=Borrower.objects.filter(student__roll_no=p)
            result=a
            context={'result':result,'p':p,}
            return render(request, 'borrowerlistp.html',context)
        else:
            result="borrower not found"
            context={'result':result,'p':p,}
            return render(request, 'resultp.html',context)
    else:
        result="borrower not found as student invalid"
        return render(request, 'result1.html',{'result':result})
def studentDetailbyroll(request,parameter):
    if Student.objects.filter(roll_no=parameter).exists():
       data=Student.objects.get(roll_no=parameter)
       context={'i':data,'p':parameter,}
       return render(request, 'studentDetailp.html',context)
    else:
        data="student not found"
        context={'result':data,'p':parameter,}
        return render(request, 'resultp.html',context)
def genrelistp(request,parameter):
    result=Genre.objects.all()
    context={'result':result,'p':parameter}
    return render(request, 'genrelistp.html',context)
def lanlistp(request,parameter):
    result=Language.objects.all()
    context={'result':result,'p':parameter}
    return render(request, 'lanlistp.html',context)
def bookdetailform1p(request,parameter):
    return render(request,'bookdetailform1p.html',{'p':parameter})
def bookdetailform2p(request,parameter):
    return render(request,'bookdetailform2p.html',{'p':parameter})
def bookdetail1p(request,parameter):
    if request.method == "POST" :
        if Book.objects.filter(genre__name=request.POST['genre']).exists():
           data=Book.objects.filter(genre__name=request.POST['genre'])
           context={'result':data,'p':parameter,}
           return render(request, 'bookdetailp.html',context)
        else:
           data="Books not found"
           context={'result':data,'p':parameter,}
           return render(request, 'resultp.html',context)
def bookdetail2p(request,parameter):
    if request.method == "POST" :
        if Book.objects.filter(language__name=request.POST['language']).exists():
           data=Book.objects.filter(language__name=request.POST['language'])
           context={'result':data,'p':parameter,}
           return render(request, 'bookdetailp.html',context)
        else:
           data="Books not found"
           context={'result':data,'p':parameter,}
           return render(request, 'resultp.html',context)

def home(request):
    return render(request,'home.html')
        



    
    
    




        

