from rest_framework import serializers
from book.models import Student,Genre,Language,Book,Borrower
class Studentserializer(serializers.ModelSerializer):
      class Meta:
            model=Student
            fields='__all__'
            extra_kwargs = {'roll_no': {'required': True, 'allow_blank': False}}
            extra_kwargs = {'password': {'required': True,'allow_blank': False}}
class Genreserializer(serializers.ModelSerializer):
      class Meta:
            model=Genre
            fields='__all__'
class Lanserializer(serializers.ModelSerializer):
      class Meta:
            model=Language
            fields='__all__'
class Bookserializer(serializers.ModelSerializer):
      class Meta:
            model=Book
            fields='__all__'
class Bookupdateserializer(serializers.ModelSerializer):
      class Meta:
            model=Book
            exclude=('total_copies','available_copies',)
