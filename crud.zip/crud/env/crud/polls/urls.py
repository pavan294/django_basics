from django.urls import path

from . import views

urlpatterns=[
            path('',views.stdisplay,name='stdisplay'),
            path('create',views.stinsert,name="stinsert"),
            path('{edit/<int:id>',views.stedit,name="stedit"),
            path('{edit/{edit/{update/{edit/{update/<int:id>',views.stupdate,name="stupdate"),
             ]
