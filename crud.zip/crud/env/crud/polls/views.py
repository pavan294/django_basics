from django.shortcuts import render
from polls.models import Destination
from polls.forms import DestinationForm
from django.contrib import messages
# Create your views here.
def stdisplay(request):
    results=Destination.objects.all().values()
    return render(request,'index1.html',{'c':results})
def stinsert(request):
    if request.method=="POST":
       s=Destination()
       s.name=request.POST.get('name')
       s.place=request.POST.get('place')
       s.password=request.POST.get('password')
       s.save()
       messages.success(request,"the Record"+s.name+"saved")
       return render(request,'create.html')
    else:
        return render(request,'create.html')
def stedit(request,id):
    a=Destination.objects.get(id=id)
    return render(request,'edit1.html',{'c':a})
def stupdate(request,id):
    a=Destination.objects.get(id=id)
    form=DestinationForm(request.POST,instance=a)
    if form.is_valid():
        form.save()
        messages.success("updated")
    return render(request,'edit1.html',{"c":a})
