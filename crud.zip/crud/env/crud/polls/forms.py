from polls.models import Destination
from django import forms
from django.forms import ModelForm
class DestinationForm(ModelForm):
    password = forms.CharField(max_length=32, widget=forms.PasswordInput)
    class Meta:
          model=Destination
          fields='__all__'
'''
from django import forms

class DestinationForm(forms.Form):
       name= forms.CharField(max_length=200)
       place= forms.CharField(max_length=200,widget=forms.Textarea)
'''
