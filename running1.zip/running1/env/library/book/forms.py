from django import forms
from book.models import Student,Book,Borrower
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit
from django.core.exceptions import ValidationError
class StudentForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    class Meta:
        model = Student
        exclude=('total_books_due',)
    def clean(self):
        super(StudentForm, self).clean()
        password=self.cleaned_data['password']
        special_characters = "[~\!@#\$%\^&\*\(\)_\+{}\":;'\[\]]"
        if not any(char.isdigit() for char in password):
            raise ValidationError("password has no numeric")
        elif not any(char.isalpha() for char in password):
            raise ValidationError("Password has no alpha character")
        elif not any(char in special_characters for char in password):
            raise ValidationError("Password has no special character")
        elif len(password)<6:
            raise ValidationError("Password has not enough length")
        
class BookForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(BookForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()  
        self.helper.form_class = 'form-horizontal'
        self.helper.label_class = 'col-lg-2'
        self.helper.field_class = 'col-lg-8'
        self.fields['summary'].widget.attrs['style']  = 'height: 100px'
        self.helper.add_input(Submit('submit', 'Submit', css_class='btn-success'))
    class Meta:
        model = Book
        fields = '__all__'
class BookUpdateForm(forms.ModelForm):
      def __init__(self, *args, **kwargs):
        super(BookUpdateForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()  
        self.helper.form_class = 'form-horizontal'
        self.helper.label_class = 'col-lg-2'
        self.helper.field_class = 'col-lg-8'
        self.fields['summary'].widget.attrs['style']  = 'height: 100px'
        self.helper.add_input(Submit('submit', 'Submit', css_class='btn-success'))
      class Meta:
        model = Book
        exclude=('title','total_copies','available_copies',)
class BorrowerForm(forms.ModelForm):
      class Meta:
        model = Borrower
        fields="__all__"